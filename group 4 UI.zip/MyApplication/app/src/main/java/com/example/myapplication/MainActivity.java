package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;  // Import Log class
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";  // Corrected declaration for TAG

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);  // Enables edge-to-edge
        setContentView(R.layout.activity_main);

        // Adjust padding based on system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onStart() {
        super.onStart();  // Call super method
        Log.d(TAG, "onStart is invoked");
    }

    @Override
    protected void onResume() {
        super.onResume();  // Call super method
        Log.d(TAG, "onResume is invoked");
    }

    @Override
    protected void onPause() {
        super.onPause();  // Call super method
        Log.d(TAG, "onPause is invoked");
    }

    @Override
    protected void onStop() {
        super.onStop();  // Call super method
        Log.d(TAG, "onStop is invoked");
    }
}